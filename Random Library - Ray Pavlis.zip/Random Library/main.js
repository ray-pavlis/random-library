
document.addEventListener("click", runCode);

function runCode() {
    let h1El = document.getElementById("output")
    h1El.innerHTML = randomInt(50, 90);
    h1El.style.color = randomRGB();
}